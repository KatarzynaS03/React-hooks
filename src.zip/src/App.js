import './App.css';
import FormikMaterialUI from "./FormikMaterialUI";

function App() {

  return (
      <div className="App">
        <FormikMaterialUI></FormikMaterialUI>
      </div>
  );
}

export default App;
