import React, {useState} from 'react';
import {isEmptyArray, useFormik} from 'formik';
import * as yup from "yup";
import axios from "axios";
import './style.css';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import {Card, CardContent, Grid, Typography} from "@mui/material";

function FormikMaterialUI() {

    const[name, setName] = useState([]);

    async function renderMovies(value){
        const url = 'http://universities.hipolabs.com/search?name=' + value.miasto + '&country=' +
            value.kraj;

        const result = await axios.get(url);
        const data = result.data;
        const nazwaa = [];

        data.map((row) => {
            nazwaa.push({name : row.name, web: row.web_pages})
        });
        setName(nazwaa);

        if(isEmptyArray(data)){
            alert(JSON.stringify('Niepoprane dane! Uniwersytet w mieście ' + value.miasto
                + ' i państwie ' + value.kraj+" nie istnieje!",  null, 2))
        }

    }

    const validationSchema = yup.object({
        kraj: yup
            .string('Podaj nazwę państwo')
            .required('Konieczne jest podanie nazwy państwa'),
        miasto: yup
            .string('Podaj nazwę miasta')
            .required('Konieczne jest podanie nazwy miasta')


    });

    const formik = useFormik({
        initialValues: {
            kraj: '',
            miasto: ''
        },
        validationSchema: validationSchema,
        onSubmit: (values) => {
            renderMovies(values);
        }
    });

    function Uni(){
        return(
            name.map(cord =>
                <Grid className="backround">
                <Card>
                    <CardContent>
                        <Typography variant="p" component="h4">
                            {cord.name}
                        </Typography>
                        <Typography variant="body2" component="h5">
                            <a href= {cord.web} rel="noreferrer">
                                Website
                            </a>
                        </Typography>
                    </CardContent>
                </Card></Grid>
            )
        )
    }

    function niMa(){
        formik.setValues(formik.initialValues);
    }

    return (
        <div>
            <h1>Podaj nazwę miasta i państwa</h1>
            <form onSubmit={formik.handleSubmit}>
                <TextField
                    fullWidth
                    id="kraj"
                    name="kraj"
                    label="Państwo"
                    value={formik.values.kraj}
                    onChange={formik.handleChange}
                    error={formik.touched.kraj && Boolean(formik.errors.kraj)}
                    helperText={formik.touched.kraj && formik.errors.kraj}
                    placeholder="Podaj nazwę państwa"
                />
                <TextField
                    fullWidth
                    id="miasto"
                    name="miasto"
                    label="Miasto"
                    value={formik.values.miasto}
                    onChange={formik.handleChange}
                    error={formik.touched.miasto && Boolean(formik.errors.miasto)}
                    helperText={formik.touched.miasto && formik.errors.miasto}
                    placeholder="Podaj nazwę miasta"
                />


                <Button color="primary" variant="contained" fullWidth type="submit">
                    Zatwierdź
                </Button>
                <Button className="przycisk"  variant="contained" fullWidth  type="reset" onClick={niMa}>
                    Wyczyść
                </Button>
            </form>

            <Uni></Uni>

        </div>


    );
}

export default FormikMaterialUI;